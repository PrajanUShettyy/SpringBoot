package net.javaguides.springboot;

public interface Computer {
	void run();

}
